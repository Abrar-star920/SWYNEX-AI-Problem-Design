"""Analysis: KPIs, breakdowns and charts from data/cleaned_orders.csv.
Run from the repo root:  python python/analysis.py
"""
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

d = pd.read_csv("data/cleaned_orders.csv", parse_dates=["OrderDate"])
d["Revenue"] = d["Quantity"] * d["Price"]
d["Month"] = d["OrderDate"].dt.to_period("M").astype(str)

total = d["Revenue"].sum()
print(f"Orders: {len(d)} | Revenue: {total:,.0f} | AOV: {total/len(d):,.0f} | Units: {d['Quantity'].sum():.0f}")
named = d[d["CustomerName"] != "Unknown"]
print("Customers:", named["CustomerName"].nunique())

def breakdown(col):
    t = d.groupby(col)["Revenue"].agg(Revenue="sum", Orders="count", AOV="mean")
    t["Share_%"] = (t["Revenue"] / total * 100).round(1)
    t[["Revenue", "AOV"]] = t[["Revenue", "AOV"]].round(0)
    return t.sort_values("Revenue", ascending=False)

out = {c: breakdown(c) for c in ["Category", "City", "Month"]}
for k, v in out.items():
    print(f"\n--- by {k} ---\n{v.to_string()}")
top = named.groupby("CustomerName")["Revenue"].sum().nlargest(10)
print("\n--- top 10 customers ---\n", top.round(0).to_string())
print("top 10 customers' share of revenue: %.1f%%" % (top.sum() / total * 100))

plt.rcParams.update({"axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 130})
fig, ax = plt.subplots(figsize=(8, 3.6))
m = out["Month"].sort_index()
ax.plot(m.index, m["Revenue"] / 1e5, marker="o", color="#2563eb")
ax.set(title="Monthly revenue (lakh)", ylabel="lakh")
plt.xticks(rotation=45); plt.tight_layout(); plt.savefig("images/monthly_revenue.png"); plt.close()

for col, fn in [("Category", "revenue_by_category"), ("City", "revenue_by_city")]:
    fig, ax = plt.subplots(figsize=(6, 3.4))
    t = out[col]
    ax.bar(t.index, t["Revenue"] / 1e5, color="#2563eb")
    ax.set(title=f"Revenue by {col.lower()} (lakh)", ylabel="lakh")
    plt.tight_layout(); plt.savefig(f"images/{fn}.png"); plt.close()
for k, v in out.items():
    v.to_csv(f"data/summary_by_{k.lower()}.csv")
