"""
Task 1 - Data Cleaning & Preparation (Python + SQL)
Python: loads raw CSV, runs the SQL scripts, validates, exports.
SQL (SQLite): profiles the raw data and performs the cleaning (sql/*.sql).
"""
import sqlite3
import pandas as pd

DB = "orders_cleaning.db"

# 1. Load raw CSV as text so nothing is silently converted
raw = pd.read_csv("data/raw_orders.csv", dtype=str, keep_default_na=False)
conn = sqlite3.connect(DB)
raw.to_sql("raw_orders", conn, if_exists="replace", index=False)

# 2. Profile the raw data with SQL
print("=== RAW DATA PROFILE (sql/01_profile.sql) ===")
for stmt in open("sql/01_profile.sql").read().split(";"):
    lines = [l for l in stmt.splitlines() if not l.strip().startswith("--")]
    stmt = "\n".join(lines).strip()
    if stmt:
        print(pd.read_sql_query(stmt, conn).to_string(index=False), "\n")

# 3. Clean with SQL
conn.executescript(open("sql/02_clean.sql").read())
conn.commit()

# 4. Validate the cleaned table
clean = pd.read_sql_query("SELECT * FROM cleaned_orders", conn)
clean["OrderDate"] = pd.to_datetime(clean["OrderDate"], format="%Y-%m-%d")
print("=== VALIDATION ===")
print("rows before:", len(raw), "| rows after:", len(clean))
print("nulls:\n", clean.isna().sum().to_string())
assert clean["OrderID"].is_unique, "duplicate OrderIDs remain"
assert (clean["Quantity"] > 0).all(), "invalid quantity remains"
assert clean["Price"].dtype.kind == "f", "Price not numeric"
print("dtypes:\n", clean.dtypes.to_string())
print("cities:", sorted(clean["City"].unique()))
print("categories:", sorted(clean["Category"].unique()))
print("date range:", clean["OrderDate"].min().date(), "to", clean["OrderDate"].max().date())
print("unknown customers:", (clean["CustomerName"] == "Unknown").sum())

# 5. Export
clean["OrderDate"] = clean["OrderDate"].dt.strftime("%Y-%m-%d")
clean.to_csv("data/cleaned_orders.csv", index=False)
print("\nSaved cleaned_orders.csv")
conn.close()
