-- 02_clean.sql : build the cleaned table from raw_orders

DROP TABLE IF EXISTS stg;
DROP TABLE IF EXISTS valid;
DROP TABLE IF EXISTS cleaned_orders;

-- Step 1: fix types, trim whitespace, standardize text, parse the 4 date formats
CREATE TABLE stg AS
SELECT
  rowid AS rn,
  CAST(OrderID AS INTEGER)                         AS OrderID,
  NULLIF(TRIM(CustomerName), '')                   AS CustomerName,
  CASE LOWER(TRIM(City))
    WHEN 'delhi' THEN 'Delhi'   WHEN 'new delhi' THEN 'Delhi'
    WHEN 'mumbai' THEN 'Mumbai' WHEN 'bombay' THEN 'Mumbai'
    WHEN 'bangalore' THEN 'Bangalore' WHEN 'bengaluru' THEN 'Bangalore'
    WHEN 'chennai' THEN 'Chennai'
    ELSE TRIM(City) END                            AS City,
  CASE LOWER(TRIM(Category))
    WHEN 'electronics' THEN 'Electronics' WHEN 'furniture' THEN 'Furniture'
    WHEN 'clothing' THEN 'Clothing'       WHEN 'groceries' THEN 'Groceries'
    ELSE TRIM(Category) END                        AS Category,
  CAST(NULLIF(TRIM(Quantity), '') AS INTEGER)      AS Quantity,
  ROUND(CAST(REPLACE(TRIM(Price), '$', '') AS REAL), 2) AS Price,
  CASE
    WHEN TRIM(OrderDate) GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'
      THEN TRIM(OrderDate)
    WHEN TRIM(OrderDate) GLOB '[0-9][0-9]/[0-9][0-9]/[0-9][0-9][0-9][0-9]'
      THEN substr(OrderDate,7,4)||'-'||substr(OrderDate,4,2)||'-'||substr(OrderDate,1,2)
    WHEN TRIM(OrderDate) GLOB '[0-9][0-9]-[0-9][0-9]-[0-9][0-9][0-9][0-9]'
      THEN substr(OrderDate,7,4)||'-'||substr(OrderDate,1,2)||'-'||substr(OrderDate,4,2)
    WHEN TRIM(OrderDate) GLOB '[0-9][0-9]-[A-Za-z][A-Za-z][A-Za-z]-[0-9][0-9][0-9][0-9]'
      THEN substr(OrderDate,8,4)||'-'||
           CASE LOWER(substr(OrderDate,4,3))
             WHEN 'jan' THEN '01' WHEN 'feb' THEN '02' WHEN 'mar' THEN '03'
             WHEN 'apr' THEN '04' WHEN 'may' THEN '05' WHEN 'jun' THEN '06'
             WHEN 'jul' THEN '07' WHEN 'aug' THEN '08' WHEN 'sep' THEN '09'
             WHEN 'oct' THEN '10' WHEN 'nov' THEN '11' WHEN 'dec' THEN '12' END
           ||'-'||substr(OrderDate,1,2)
  END                                              AS OrderDate
FROM raw_orders;

-- Step 2: remove invalid rows (negative quantity, missing/unparseable date)
-- and de-duplicate (exact duplicates and repeated OrderIDs; keep first seen)
CREATE TABLE valid AS
SELECT * FROM (
  SELECT *, ROW_NUMBER() OVER (PARTITION BY OrderID ORDER BY rn) AS rk
  FROM stg
  WHERE (Quantity IS NULL OR Quantity >= 0)
    AND OrderDate IS NOT NULL
) WHERE rk = 1;

-- Step 3: fill missing values (Quantity -> median, CustomerName -> 'Unknown')
CREATE TABLE cleaned_orders AS
SELECT
  OrderID,
  COALESCE(CustomerName, 'Unknown') AS CustomerName,
  City, Category,
  COALESCE(Quantity,
    (SELECT Quantity FROM valid WHERE Quantity IS NOT NULL
     ORDER BY Quantity
     LIMIT 1 OFFSET (SELECT (COUNT(Quantity) - 1) / 2 FROM valid))) AS Quantity,
  Price,
  OrderDate
FROM valid
ORDER BY OrderID;
