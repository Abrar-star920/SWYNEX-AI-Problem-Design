-- 01_profile.sql : profile the RAW table (all columns loaded as text)

-- Row count
SELECT COUNT(*) AS total_rows FROM raw_orders;

-- Missing values per column (empty string = missing)
SELECT
  SUM(TRIM(CustomerName) = '') AS missing_customer_name,
  SUM(TRIM(Quantity)     = '') AS missing_quantity,
  SUM(TRIM(Price)        = '') AS missing_price,
  SUM(TRIM(OrderDate)    = '') AS missing_order_date
FROM raw_orders;

-- Exact duplicate rows
SELECT COUNT(*) AS exact_duplicate_rows FROM (
  SELECT OrderID, CustomerName, City, Category, Quantity, Price, OrderDate, COUNT(*) c
  FROM raw_orders GROUP BY 1,2,3,4,5,6,7 HAVING c > 1);

-- Repeated OrderIDs
SELECT COUNT(*) AS orderids_appearing_more_than_once FROM (
  SELECT OrderID FROM raw_orders GROUP BY OrderID HAVING COUNT(*) > 1);

-- Wrong data type: Price values stored with a currency symbol
SELECT COUNT(*) AS prices_with_dollar_sign FROM raw_orders WHERE Price LIKE '$%';

-- Invalid values
SELECT COUNT(*) AS negative_quantity FROM raw_orders WHERE CAST(NULLIF(TRIM(Quantity),'') AS INTEGER) < 0;

-- Inconsistent categorical values
SELECT City, COUNT(*) AS n FROM raw_orders GROUP BY City ORDER BY City;
SELECT Category, COUNT(*) AS n FROM raw_orders GROUP BY Category ORDER BY Category;
